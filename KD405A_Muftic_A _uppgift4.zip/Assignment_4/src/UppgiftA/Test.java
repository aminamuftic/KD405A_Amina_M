package UppgiftA;

public class Test {

	public static void main(String[] args) {
Human human = new Human (" Lisa ");
human.buyDog (" Molly ");
System.out.println(human.getInfo());
	}

}
